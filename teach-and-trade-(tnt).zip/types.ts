export type ViewState = 'HOME' | 'DASHBOARD' | 'CREATE_LISTING' | 'COURSE_DETAIL' | 'CLASSROOM';

export enum UserRole {
  LEARNER = 'LEARNER',
  TRAINER = 'TRAINER',
  ADMIN = 'ADMIN',
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  skills_offered: string[];
  skills_wanted: string[];
  rating: number;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Course {
  id: string;
  trainer_id: string;
  trainer_name: string;
  title: string;
  description: string;
  category: string;
  price: number;
  is_barter_enabled: boolean;
  barter_skills_wanted?: string[];
  duration: string;
  location: string; // "Online" or specific city
  rating: number;
  reviews_count: number;
  image_url: string;
  tags: string[];
}

export interface Booking {
  id: string;
  course_id: string;
  course_title: string;
  learner_id: string;
  status: 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED';
  date: string;
  time?: string;
  type: 'PAID' | 'BARTER';
  price_paid?: number;
}