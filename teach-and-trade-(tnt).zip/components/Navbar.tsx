import React from 'react';
import { ViewState, User } from '../types';
import { Layout, User as UserIcon, PlusCircle, LogOut } from 'lucide-react';

interface NavbarProps {
  user: User;
  setView: (view: ViewState) => void;
  currentView: ViewState;
}

const Navbar: React.FC<NavbarProps> = ({ user, setView, currentView }) => {
  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center cursor-pointer" onClick={() => setView('HOME')}>
            <div className="flex-shrink-0 flex items-center gap-2">
              <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
                T
              </div>
              <span className="font-bold text-xl text-slate-800 tracking-tight">Teach & Trade</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => setView('CREATE_LISTING')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors
                ${currentView === 'CREATE_LISTING' 
                  ? 'bg-brand-50 text-brand-700' 
                  : 'text-slate-600 hover:bg-slate-50'}`}
            >
              <PlusCircle size={18} />
              <span className="hidden sm:inline">List a Skill</span>
            </button>

            <button
              onClick={() => setView('DASHBOARD')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors
                ${currentView === 'DASHBOARD' 
                  ? 'bg-brand-50 text-brand-700' 
                  : 'text-slate-600 hover:bg-slate-50'}`}
            >
              <Layout size={18} />
              <span className="hidden sm:inline">Dashboard</span>
            </button>

            <div className="h-8 w-px bg-slate-200 mx-1"></div>

            <div className="flex items-center gap-3">
              <span className="text-sm font-medium text-slate-700 hidden md:block">{user.name}</span>
              <div className="w-9 h-9 rounded-full bg-slate-200 overflow-hidden border border-slate-300">
                 <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;