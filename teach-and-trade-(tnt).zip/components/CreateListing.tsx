import React, { useState } from 'react';
import { ViewState } from '../types';
import { generateAiDescription } from '../services/geminiService';
import { Wand2, Loader2, ArrowLeft, CheckCircle } from 'lucide-react';

interface CreateListingProps {
  onBack: () => void;
  onSave: () => void;
}

const CreateListing: React.FC<CreateListingProps> = ({ onBack, onSave }) => {
  const [title, setTitle] = useState('');
  const [skills, setSkills] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [isBarter, setIsBarter] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleGenerate = async () => {
    if (!title || !skills) {
      alert("Please enter a title and some skills first.");
      return;
    }
    setIsGenerating(true);
    const desc = await generateAiDescription(title, skills);
    setDescription(desc);
    setIsGenerating(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      onSave();
    }, 1500); // Mock API delay
  };

  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <button 
        onClick={onBack} 
        className="flex items-center text-slate-500 hover:text-brand-600 mb-6 transition-colors"
      >
        <ArrowLeft size={18} className="mr-1" /> Back to Marketplace
      </button>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-8 py-6 border-b border-slate-100 bg-slate-50/50">
          <h2 className="text-2xl font-bold text-slate-900">Create a New Listing</h2>
          <p className="text-slate-500">Share your expertise with the world.</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          
          <div className="grid grid-cols-1 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Course Title</label>
              <input
                type="text"
                required
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-colors"
                placeholder="e.g., Advanced Pottery Workshop"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Skills / Keywords</label>
              <input
                type="text"
                required
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-colors"
                placeholder="e.g., Ceramics, Glazing, Hand-building"
                value={skills}
                onChange={(e) => setSkills(e.target.value)}
              />
              <p className="text-xs text-slate-400 mt-1">Used for search matching and AI description generation.</p>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium text-slate-700">Description</label>
                <button
                  type="button"
                  onClick={handleGenerate}
                  disabled={isGenerating || !title}
                  className="text-xs flex items-center gap-1 text-brand-600 font-semibold hover:text-brand-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isGenerating ? <Loader2 size={12} className="animate-spin"/> : <Wand2 size={12} />}
                  Generate with AI
                </button>
              </div>
              <textarea
                required
                rows={5}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-colors"
                placeholder="Describe what students will learn..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
               <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Price ($)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-500">$</span>
                  <input
                    type="number"
                    required
                    min="0"
                    className="w-full pl-7 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500"
                    placeholder="50"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex items-center h-full pt-6">
                <label className="flex items-center cursor-pointer gap-3">
                  <div className="relative inline-flex items-center">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={isBarter}
                      onChange={(e) => setIsBarter(e.target.checked)}
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                  </div>
                  <span className="text-sm font-medium text-slate-700">Open to Barter / Skill Swap</span>
                </label>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 flex justify-end gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-6 py-2 border border-slate-300 rounded-lg text-slate-700 font-medium hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2 bg-brand-600 text-white rounded-lg font-medium hover:bg-brand-700 transition-colors flex items-center gap-2 disabled:opacity-75"
            >
              {isSaving ? <Loader2 size={18} className="animate-spin" /> : <CheckCircle size={18} />}
              Publish Course
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateListing;